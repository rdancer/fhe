#ifndef SLEEP_INT_H_INCLUDED
#define SLEEP_INT_H_INCLUDED

void
xmlrpc_millisecond_sleep(unsigned int const milliseconds);

#endif
