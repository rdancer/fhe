#ifndef XMLRPC_WININET_TRANSPORT_H
#define XMLRPC_WININET_TRANSPORT_H

#include "xmlrpc-c/transport.h"

extern struct xmlrpc_client_transport_ops xmlrpc_wininet_transport_ops;

#endif
