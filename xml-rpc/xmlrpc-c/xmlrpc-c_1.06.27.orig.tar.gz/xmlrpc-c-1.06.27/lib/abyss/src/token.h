#ifndef ABYSS_TOKEN_H_INCLUDED
#define ABYSS_TOKEN_H_INCLUDED

void
NextToken(const char ** const pP);

char *
GetToken(char ** const pP);


#endif
