#ifndef SOCKET_WIN_H_INCLUDED
#define SOCKET_WIN_H_INCLUDED

void
SocketWinInit(abyss_bool * const succeededP);

void
SocketWinTerm(void);

#endif
